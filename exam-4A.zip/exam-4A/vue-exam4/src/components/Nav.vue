<script>
export default {
    data(){
        return {
            searchName:''
        }
    },
    methods:{
        search(){
            this.$emit('search-pet',this.searchName);
        }
    }
}
</script>


<template>
    <nav>
        <router-link to="/">Home</router-link>|
        <router-link to="/pets">View Pets</router-link>

   
    <div>
        <input type="text" placeholder="Enter the pet name " v-model="searchName">
        <button @click="search">Search</button>

    </div>

</nav>

</template>